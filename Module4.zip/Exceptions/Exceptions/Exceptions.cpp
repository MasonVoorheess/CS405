
// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
int catcher=0;
int catcher1 = 0;
bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
        else {
            catcher = 2;
        }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    std::string dog = "cat";
        if (dog == "cat")
        {
            catcher1 = 1;
        }


    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    auto result = 0;
    if (denominator == 0) // !! Division by zero
        catcher = 1;
    else
        auto result = divide(numerator, denominator);

    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    try {
        
        do_division();
        if (catcher == 1)
        {
            throw std::exception("division by zero error");
        }
        do_custom_application_logic();
        if (catcher == 2)
        {
            throw std::exception("logic error");
        }
        if (catcher1 == 1)
        {
            throw std::exception("dog is equal to cat");
        }
       
    }
    catch (std::exception exception)
    {
        std::cout << "Exception Caught."<< exception.what() << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu